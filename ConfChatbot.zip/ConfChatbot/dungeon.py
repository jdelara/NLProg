from player import Player

class Dungeon:
    def __init__(self):
        self.players = []
        self.rooms = 0
        self.characters = []
        self.objects = []
    def set_number_of_rooms(self,number):
        self.rooms = number
    
    def add_player(self, player):
        self.players.append(player)
    
    def get_player(self):
        return self.players[-1]

    def check_name(self, name):
        return any(player.name == name for player in self.players)
    
    def print_players(self):
        sen = ""
        for player in self.players:            
            sen += "\t\t\t\t\t\t- Name: " + player.name + "\n\t\t\t\t\t\t- Health: " + str(player.health) + " HP\n\n"
        return sen[:-1]
    
    def dungeon_info(self):
        return "The dungeon has:\n\t\t- " + str(len(self.players)) + " Player(s):\n" + self.print_players() + "\t\t- " + str(len(self.characters)) + \
         " Character(s):\n\t\t- " + str(len(self.objects)) + " Object(s):\n\t\t- " + str(self.rooms) + " room(s)."
        
    def reset(self):
        self.players = []
        self.rooms = 0
        self.characters = []
        self.objects = []
        